from api_framework.client import Client


class OrderManager(Client):

    def create_order(self, json: dict):
        """
        Создание заказа
        """
        return Client._s.post(Client.host + f"/order-manager/v1/orders", json=json, verify=False)
