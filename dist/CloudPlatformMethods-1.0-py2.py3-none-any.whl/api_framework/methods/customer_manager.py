from api_framework.client import Client


class CustomerManager(Client):

    def get_customers_clouds(self):
        """
        Получение списка облаков текущего пользователя
        """
        return Client._s.get(Client.host + f"/customer-manager/v1/clouds", verify=False)

    def create_cloud(self, json: dict):
        """
        Создание облака
        """
        return Client._s.post(Client.host + f"/customer-manager/v1/cloud", json=json, verify=False)

    def update_cloud(self, cloud_id: str, json: dict):
        """
        Обновление облака
        """
        return Client._s.put(Client.host + f"/customer-manager/v1/cloud/{cloud_id}", json=json, verify=False)

    def get_all_depts_in_cloud(self, cloud_id: str):
        """
        Получение списка департаментов в облаке
        """
        return Client._s.get(Client.host + f"/customer-manager/v1/ou?cloud_id={cloud_id}", verify=False)

    def get_dept(self, id: str):
        """
        Возвращает данные департамента по ID
        """
        return Client._s.get(Client.host + f"/customer-manager/v1/ou/{id}", verify=False)

    def create_dept(self, json: dict):
        """
        Создание департамента. Необходимые поля: "cloud_id","name","description","limit"
        """
        return Client._s.post(Client.host + f"/customer-manager/v1/ou", json=json, verify=False)

    def update_dept(self, ou_id: str, json: dict):
        """
        Изменение данных департамента в полях: "name","description","limit"
        """
        return Client._s.put(Client.host + f"/customer-manager/v1/ou/{ou_id}", json=json, verify=False)

    def delete_dept(self, ou_id: str):
        """
        Удаление департамента
        """
        return Client._s.delete(Client.host + f"/customer-manager/v1/ou/{ou_id}", verify=False)

    def get_customers_data(self, id: str):
        """
        Получение данных клиента (организации) по ID
        """
        return Client._s.get(Client.host + f"/customer-manager/v1/customer/{id}", verify=False)

    def create_customer(self, json: dict):
        """
        Создание клиента
        """
        return Client._s.post(Client.host + f"/customer-manager/v1/customer", json=json, verify=False)

    def update_customer(self, id: str, json: dict):
        """
        Обновление клиента
        """
        return Client._s.put(Client.host + f"/customer-manager/v1/customer/{id}", json=json, verify=False)
