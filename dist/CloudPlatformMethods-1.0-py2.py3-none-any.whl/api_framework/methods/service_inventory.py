from api_framework.client import Client


class ServiceInventory(Client):
    pass
